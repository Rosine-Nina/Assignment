This is the Lab 2 exercise
