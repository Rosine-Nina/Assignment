
package Cars;

public interface Automobile  {
    public void speed(int car_speed);
    public int mileage(int car_mileage);
    public void enginePower();
    
}
